
document.addEventListener("DOMContentLoaded", () => {
  console.log("Casino Mil Grau BR carregado!");
});
