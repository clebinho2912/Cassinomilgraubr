import React from "react";
import CasinoMilGrauBR from "./CasinoMilGrauBR";

function App() {
  return <CasinoMilGrauBR />;
}

export default App;